package model

type User struct {
	Username string
}
